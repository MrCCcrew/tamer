import {Helpers} from "../common/helpers.js";
import {Settings} from "../common/settings.js";
import {debug, debugError, debugInfo} from "../common/debug.js";

export class BaseNetworkHandler {
  tab;
  yaSuccessCompleteTag = 'extension_network_success_complete';
  yaErrorCompleteTag = 'extension_network_error_complete';

  async checkLogin() {
    return true;
  }

  async openTab(url, sleepAfterSeconds, forceActive = false) {
    return new Promise(async (resolve, reject) => {
      try {
        let tabWasUpdated = false;
        if (this.tab !== undefined) {
          if (forceActive) {
            try {
              chrome.tabs.remove([this.tab.id]);
            } catch (e) {}
          }
          else {
            tabWasUpdated = await new Promise(async (r) => {
              chrome.tabs.get(this.tab.id, () => r(chrome.runtime.lastError === undefined));
            });
            if (tabWasUpdated) {
              let currentTab = this.tab;
              chrome.tabs.update(this.tab.id, {url: url, active: true}, tabItem => {
                setTimeout(() => {resolve(true)}, 2000);
              });
            }
          }
        }

        if (!tabWasUpdated) {
          // для пк использовался pinned, что бы не засорять вкладки. Сделать ли опционально?
          // chrome.tabs.create({url: url, active: false, "pinned": true}, tabItem => {
          chrome.tabs.create({url: url, active: true}, tabItem => {
            if (tabItem) {
              this.tab = tabItem;
              setTimeout(() => {resolve(true)}, 2000);
            }
          });
        }
      } catch (e) {
        reject(e)
      }
    }).then(async (res) => {
      let setting = await Settings.getSettings();
      setting.network = this;
      if (res) {
        if (setting.isDebug) {
          this.overlayPopup(await setting.common.log)
        }
        else {
          this.overlayPopup()
          this.onCloseHandler()
        }
        if (sleepAfterSeconds) {
          await Helpers.sleep(sleepAfterSeconds);
        }
      }
      return res;
    })
  }

  onCloseHandler() {
    chrome.tabs.onRemoved.addListener((tabId, removalInfo) => {
      if (tabId === this.tab.id) {
        debugInfo('BaseNetworkHandler', 'close_tab', JSON.stringify(removalInfo))
      }
    });
  }

  overlayPopup(overlayText = 'GetLike clicker IS WORKING...') {
    this.scripting(
      (overlayText) => {

        let el = document.querySelector('#bot-liker-popup');
        if (el == null) {
          el = document.createElement('div');
          el.setAttribute("id", "bot-liker-popup");
          document.documentElement.appendChild(el);
        }

        el.innerHTML = `
        <div style="position: fixed;
          top: 0;
          width: 100%;
          height: 100%;
          background-color: rgba(0, 0, 0, .6);
          z-index: 100000">
          <div style="text-align: center;
            width: min-content;
            max-height: 200px;
            overflow: auto;
            margin: 100px auto;
            padding: 10px 30px;
            border-radius: 70px;
            background-image: -moz-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
            background-image: -webkit-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
            background-image: -ms-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
            background-image: linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
            color: #fff;
            font-weight: 700;
            box-shadow: 2px 2px 9px rgba(0, 0, 0, .3);
            flex-direction: initial;
            padding-left: 22px;
            padding-top: 13px"
          >
            <div style="  display: inline-block;width: fit-content"></div> 
            <div style=" display: inline-block;width: max-content;text-align: left;margin-left: 10px;">
              <span class="working">${overlayText}</span>
              <br><span id="bot-liker-additional-overlay-popup-info"></span>
            </div>
          </div>
        </div>`
      },
      [overlayText]
    )
  }

  static async closeTabs(urlFilter) {
    await new Promise(async (resolve, reject) => {
      chrome.tabs.query({}, async function (tabs) {
        let removeTabs = tabs.filter(i => {
          // для пк использовался pinned, что бы не засорять вкладки. Сделать ли опционально?
          // return (i.url || '').includes('tiktok') && i.pinned
          return (i.url || '').includes(urlFilter)
        });

        let settings = await Settings.getSettings();
        for (let tab of removeTabs) {
          try {
            if (tab.id === await settings.common.mainTabId) {
              continue;
            }
            let tabAvailable = await new Promise(async (r) => {
              chrome.tabs.get(tab.id, () => r(chrome.runtime.lastError === undefined));
            });
            if (tabAvailable) {
              await chrome.tabs.remove([tab.id]);
            }
          } catch (e) {}
        }

        resolve(true);
      });
    });
  }

  needReqData() {
    return false;
  }

  needReqDataComment(taskType) {
    return false;
  }

  needReqDataCommentUrl(taskType) {
    return '';
  }

  async getAdditionalAccountData(isMobile, taskType) {
    return {};
  }

  sleepMs(s) {
    return new Promise(r => setTimeout(() => r(), s));
  }

  scripting(func, args = [], resolveFunc = undefined) {
    if (resolveFunc === undefined) {
      resolveFunc = (injectionResults) => {
        return injectionResults === undefined ? false : injectionResults[0].result;
      }
    }

    return new Promise((resolve, reject) => {
      try {
        chrome.scripting
          .executeScript({
            target: {tabId: this.tab.id},
            func: func,
            args: args,
          }, (injectionResults) => {
            resolve(resolveFunc(injectionResults));
          })
      } catch (e) {
        debugError('BaseNetworkHandler', 'exception', `Exception: ${e.message}. В BaseNetworkHandler::scripting(${func.name}, ${JSON.stringify(args)})`);
        resolve(null);
      }
    })
  }
}