export const _functions = {
  checkLogin: async () => {
    let result = await injectCode(chrome.runtime.getURL('js/networks_handlers/tiktok/injects/checkLogin.js'));
    return result == 1;
  },
  getInfo: async () => {
    let result = await injectCode(chrome.runtime.getURL('js/networks_handlers/tiktok/injects/getInfo.js'));
    if (result != undefined) {
      return JSON.parse(result);
    }
    return undefined;
  },
  subscribe : async (onlyCheck = false, isMobile = false) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'tiktok.functions.subscribe', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const checkSubscribe = async (subscribeButton, check = false) => {
      let textsSubscribed = ['Подписки', 'Following'];

      let result = document.querySelector(isMobile ? '.tiktok-179loxr-DivFollowButtonWrapper' : '.tiktok-gvq8tv-DivFollowButtonWrapper') !== null;
      if (result === false) {
        result = document.querySelector(isMobile ? '.css-179loxr-DivFollowButtonWrapper' : '.css-gvq8tv-DivFollowButtonWrapper') !== null;
        if (result === false) {
          result = await injectCode(chrome.runtime.getURL(
            isMobile
              ? 'js/networks_handlers/tiktok/injects/checkSubscribeMobile.js'
              : 'js/networks_handlers/tiktok/injects/checkSubscribe.js'
          )) === 1 ? true : false;

          if (result === false) {
            for (let textSubscribed in textsSubscribed) {
              if (subscribeButton.innerText === textsSubscribed[textSubscribed]) {
                result = true;
                break;
              }
            }

            if (check) {
              debug('Не удалось проверить подписку всеми способами', 'error');
            }
          }
        }
      }

      return result;
    };

    let subscribeButton = document.querySelector('[data-e2e="follow-button"]');
    if (subscribeButton == null) {
      debug('Не найдена кнопка подписки', 'error')
      return false;
    }

    if (await checkSubscribe(subscribeButton)) {
      debug('Уже есть подписка')
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleep(rand(3, 6));

    debug('Подписка')
    if (isMobile) {
      subscribeButton.dispatchEvent(
        new TouchEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }
    else {
      subscribeButton.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }

    // ждем прогрузки всего
    await sleep(2);

    debug('Проверка подписки')
    if (!await checkSubscribe(subscribeButton, true)) {
      debug('Повторная проверка подписки')
      await sleep(2);
      return await checkSubscribe(subscribeButton, true);
    }
    else {
      return true;
    }
  },
  like : async (onlyCheck = false, isMobile = false) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'tiktok.functions.like', message_action: action, message_text: message});
      } catch (e) {}
    };
    const sleep = (s) => {return new Promise(r => setTimeout(() => r(), s*1000));}
    const checkLike = (check = false) => {
      let pressed = false;
      let redIcon = document.querySelector('[data-e2e="video-like-button"]')?.querySelector('[filter*="Red"]');
      if (redIcon == null) {
        redIcon = document.querySelector('[data-e2e="like-icon"]')?.querySelector('[fill="rgb(254,44,85)"]');
        if (redIcon == null) {
          pressed = document.querySelector('[data-e2e="browse-like-icon"]')?.parentNode?.getAttribute('aria-pressed') === 'true'
        }
      }
      let result = redIcon != null || pressed;
      if (!result && check) {
        debug('Не удалось проверить лайк всеми способами', 'error')
      }
      return result;
    };
    const findLikeButton = () => {
      let likeButton = document.querySelector('[data-e2e="video-like-button"]');
      if (likeButton == null) {
        likeButton = document.querySelector('[data-e2e="like-icon"]');
        if (likeButton == null) {
          likeButton = document.querySelector('[data-e2e="browse-like-icon"]');
        }
      }
      return likeButton;
    };

    let likeButton = findLikeButton();
    if (likeButton == null) {
      debug('Не найдена кнопка лайка', 'error')
      return false;
    }

    if (checkLike()) {
      debug('Лайк уже стоит');
      return true;
    }

    if (onlyCheck) {
      return false;
    }

    // случайная задержка перед действием
    const rand = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1)) + min
    }
    await sleep(rand(5, 10));

    debug('Лайк');
    if (isMobile) {
      likeButton.dispatchEvent(
        new TouchEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }
    else {
      likeButton.dispatchEvent(
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true
        })
      );
    }

    // ждем прогрузки всего
    await sleep(2);

    // Двойная проверка, бывает не успевает что-то смениться
    debug('Проверка лайка');
    if (!checkLike(true)) {
      debug('Повторная проверка лайка');
      await sleep(2);
      return checkLike(true);
    }
    else {
      return true;
    }
  },
  checkLocationHref: async (query, fullMatch = false) => {
    return fullMatch
      ? location.href === query
      : location.href.indexOf(query) >= 0;
  },
  search: async (query, isMobile) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}

    if (isMobile) {
      return false;
    }
    else  {
      let searchInputEl = document.querySelector("input[data-e2e=search-user-input]");
      searchInputEl.dispatchEvent(new Event('click'));
      searchInputEl.dispatchEvent(new Event('focus'));
      await sleepMs(500);
      searchInputEl.value = query;
      searchInputEl.dispatchEvent(new Event('paste', {bubbles: true, cancelable: true}));
      searchInputEl.dispatchEvent(new Event('input', {bubbles: true}));
      await sleepMs(500);
      document.querySelector("form[data-e2e=search-box]").submit();
    }

    return true;
  },
  selectVideoInSearch : async (isMobile, id) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}
    const find = async () => {
      let foundVideo = undefined;
      let videos = isMobile
        ? document.querySelectorAll("[data-e2e=search_top-item-list] [data-e2e=search_top-item] a")
        : document.querySelectorAll("[data-e2e=search_top-item-list] [data-e2e=search_top-item] a");
      for (let videoIndex = 0; videoIndex < videos.length; videoIndex++) {
        if (
          videos[videoIndex].href.indexOf(id) >= 0
        ) {
          foundVideo = videos[videoIndex];
          break;
        }
      }

      return foundVideo;
    }

    let foundVideo = await find();
    if (foundVideo === undefined) {
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(3000);

      foundVideo = await find();
    }

    if (foundVideo === undefined) {
      return false;
    }

    foundVideo.click();
    await sleepMs(1000);

    return true;
  },
  selectChannelInSearch : async (isMobile, username) => {
    const sleepMs = (s) => {return new Promise(r => setTimeout(() => r(), s));}
    const find = async () => {
      let foundChannel = undefined;
      let channels = isMobile
        ? document.querySelectorAll("[data-e2e=search-user-info-container] [data-e2e=search-user-unique-id]")
        : document.querySelectorAll("[data-e2e=search-user-info-container] [data-e2e=search-user-unique-id]");
      for (let channelIndex = 0; channelIndex < channels.length; channelIndex++) {
        if (channels[channelIndex].innerText === username) {
          foundChannel = channels[channelIndex];
          break;
        }
      }

      return foundChannel;
    }

    let foundVideo = await find();
    if (foundVideo === undefined) {
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(2000);
      window.scrollBy(0,15000)
      await sleepMs(3000);

      foundVideo = await find();
    }

    if (foundVideo === undefined) {
      return false;
    }

    foundVideo.click();
    await sleepMs(1000);

    return true;
  },
  isVideoAvailable: async (isMobile) => {
    if (isMobile) {
      return document.querySelector("div[class*='-DivErrorNoData']") === null;
    }
    else {
      return document.querySelector("div[class*='-DivErrorWrapper']") === null;
    }
  },
  isAccountAvailable: async (isMobile) => {
    if (isMobile) {
      return document.querySelector('[data-e2e=user-bio]') !== null
    }
    else {
      return document.querySelector('[data-e2e=user-bio]') !== null;
    }
  },
  watch : async (isMobile, seconds) => {
    const debug = (action, type = 'info', message = '') => {
      try {
        chrome.runtime.sendMessage({type: 'debug_scripting', message_type: type, message_context: 'tiktok.functions.watch', message_action: action, message_text: message});
      } catch (e) {}
    };

    let currentSeconds = 0;

    let fullPage = false;
    if (isMobile) {
      fullPage = true;
    }
    else {
      fullPage = document.querySelector("div[class*='DivPlayIconContainer']") !== null;
    }

    if (fullPage) {
      let currentSeconds = 0;
      let commonSeconds = 0;

      const isPlayingNow = () => {
        if (isMobile) {
          return document.querySelector("div[data-e2e=video-play-icon]") === null;
        }
        else {
          return document.querySelector("div[class*='DivPlayIconContainer']").querySelector("use") === null;
        }
      }
      const startPlaying = () => {
        if (isMobile) {
          return document.querySelector("div[data-e2e=video-play-icon]")?.click();
        }
        else {
          document.querySelector("div[class*='DivPlayIconContainer']").click();
        }
      }
      const checkAndStartPlaying = () => {
        try {
          if (isPlayingNow()) {
            return true;
          }
          else {
            startPlaying();
            return false;
          }
        } catch (e) {
          debug(`Неизвестная ошибка при проверке просмотра. Ошибка: ${e.message}`, 'error');
          throw new Error("buttons_not_found");
        }
      };

      return await new Promise((resolve, reject) => {
        let addInfo = document.querySelector('#bot-liker-additional-overlay-popup-info');
        let watchTimer = setInterval(function () {
          let isPlayingNow = false;
          try {
            isPlayingNow = checkAndStartPlaying();
          } catch (e) {
            if (addInfo !== null) {addInfo.innerText = '';}
            debug(`Неизвестная ошибка при просмотре ${currentSeconds} из ${seconds}. Ошибка: ${e.message}`, 'error');
            clearInterval(watchTimer);
            resolve(false)
          }

          commonSeconds++;
          if (isPlayingNow) {
            currentSeconds++;
          }

          if (currentSeconds > seconds) {
            if (addInfo !== null) {addInfo.innerText = '';}
            debug(`Успешный просмотр ${currentSeconds} из ${seconds}`);
            clearInterval(watchTimer);
            resolve(true);
          }
          if (commonSeconds/2 > seconds) { // в случае если не просмотр тянется уже в два раза дольше, вернуть.
            if (addInfo !== null) {addInfo.innerText = '';}
            debug(`Не удалось просмотреть. Потратили ${commonSeconds} из ${seconds}`, 'error');
            clearInterval(watchTimer);
            resolve(false);
          }

          if (addInfo !== null) {
            addInfo.innerText = ` Watching: ${currentSeconds} s. of ${seconds} s. (total ${commonSeconds} s.)`;
          }
        }, 1000)
      });
    }
    else {
      debug(`Просмотр НЕ fullPage`);
      return await new Promise((resolve, reject) => {
        setInterval(function () {
          currentSeconds++;
          if (currentSeconds > seconds) {
            resolve(true);
          }
        }, 1000)
      });
    }

  },
}