let isLogin = window.__$UNIVERSAL_DATA$__.__DEFAULT_SCOPE__['webapp.app-context'].user === undefined ? "0" : "1";
document.currentScript.textContent = isLogin;