let isLogin = window.yt.config_.LOGGED_IN ? "1" : "0";
document.currentScript.textContent = isLogin;