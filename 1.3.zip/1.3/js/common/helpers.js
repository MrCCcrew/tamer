export const Helpers = {
  sleep: function (s) {
    return new Promise(r => setTimeout(() => r(), s*1000));
  },
  sleepMs: function (ms) {
    return new Promise(r => setTimeout(() => r(), ms));
  },
  rand: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
  },
  shuffle: function (array) {
    return array.sort(() => Math.random() - 0.5);
  },
}